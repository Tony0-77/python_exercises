# ===============
# Option 1 
# ===============

my_list = [4, 5, 6, 7]

if len(my_list) == 0:
	print("Empty")
else:
	print("Not Empty")

# ===============
# Option 2
# ===============

my_list = [4, 5, 6, 7]

if my_list:
	print("Empty")
else:
	print("Not Empty")