my_list = [3, 4, 5, 6]

if my_list:
	print(max(my_list), min(my_list))
else:
	print(None)