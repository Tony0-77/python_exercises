# ================
# Option 1
# ================

my_list = [3, 4, 5, 6]

for elem in my_list:
	print(elem, end=" ")

# ================
# Option 2
# ================

my_list = [3, 4, 5, 6]

print(*my_list, sep=" ")

