s = "Hello59"

print(s.isdecimal())