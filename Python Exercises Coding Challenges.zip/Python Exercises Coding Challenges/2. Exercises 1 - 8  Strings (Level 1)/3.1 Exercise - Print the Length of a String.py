s = "Python"

print(len(s))
