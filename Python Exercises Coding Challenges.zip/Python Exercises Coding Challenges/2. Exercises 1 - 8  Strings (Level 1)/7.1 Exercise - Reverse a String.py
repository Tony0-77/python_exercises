# -----------
# Option 1
# -----------
s = "Hello"

print(s[::-1])

# -----------
# Option 2
# -----------
s = "Hello"

reversed_word = s[::-1]
print(reversed_word)

# -----------
# Option 3
# -----------
s = "Hello"

reversed_word = "".join(reversed(s))
print(reversed_word)