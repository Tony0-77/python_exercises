season_num = 2

if season_num == 1:
	print("Spring")
elif season_num == 2:
	print("Summer")
elif season_num == 3:
	print("Fall")
elif season_num == 4:
	print("Winter")
else:
	print("Please enter a valid number")