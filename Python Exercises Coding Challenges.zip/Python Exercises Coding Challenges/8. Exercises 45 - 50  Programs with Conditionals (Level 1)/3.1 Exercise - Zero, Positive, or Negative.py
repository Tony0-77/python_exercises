num = 5

if num == 0:
	print("Zero")
elif num > 0:
	print("Positive")
else:
	print("Negative")