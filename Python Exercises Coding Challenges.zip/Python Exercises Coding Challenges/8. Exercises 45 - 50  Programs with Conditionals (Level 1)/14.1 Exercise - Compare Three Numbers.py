# -------------
# Option 1
# -------------
a = 1
b = 2
c = 1

if (a == b) and (b == c):
	print("Equal")
else:
	print("Not Equal")


# -------------
# Option 2
# -------------
a = 1
b = 2
c = 1

if a == b == c:
	print("Equal")
else:
	print("Not Equal")