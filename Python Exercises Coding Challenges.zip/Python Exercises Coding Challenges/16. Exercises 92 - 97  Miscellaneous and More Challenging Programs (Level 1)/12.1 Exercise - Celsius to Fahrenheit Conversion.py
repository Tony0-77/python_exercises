celsius = float(input("Degrees Celsius: "))

fahrenheit = (celsius * 9/5) + 32

print(f"Degrees Fahrenheit: {fahrenheit}")