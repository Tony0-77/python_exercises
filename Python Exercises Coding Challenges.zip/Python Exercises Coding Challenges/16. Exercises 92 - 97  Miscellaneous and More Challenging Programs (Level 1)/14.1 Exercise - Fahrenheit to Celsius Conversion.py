fahrenheit = float(input("Degrees Fahrenheit: "))

celsius = (fahrenheit - 32) * 5/9

print(f"Degrees Celsius: {celsius}")