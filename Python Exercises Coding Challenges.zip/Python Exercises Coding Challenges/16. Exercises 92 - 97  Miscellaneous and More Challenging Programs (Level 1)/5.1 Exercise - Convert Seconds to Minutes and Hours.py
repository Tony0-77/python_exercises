seconds = 5400
minutes = seconds//60 
hours = minutes/60

print(seconds, "seconds is equivalent to:")
print(minutes, "minutes")
print(hours, "hours")
