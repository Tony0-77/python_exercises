import datetime

current_date_time = datetime.datetime.now()

print("Current date and time: ")
print(current_date_time.strftime("%Y-%m-%d %H:%M:%S"))