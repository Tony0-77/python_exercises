for i in range(65, 91):
	print(chr(i))