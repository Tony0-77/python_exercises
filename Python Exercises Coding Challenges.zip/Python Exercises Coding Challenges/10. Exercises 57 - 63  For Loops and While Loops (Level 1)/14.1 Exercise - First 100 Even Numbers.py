# --------------
# Option 1
# --------------

for i in range(2, 201, 2):
    print(i)

# --------------
# Option 2
# --------------

for i in range(1, 201):
    if i % 2 == 0:
        print(i)