for i in range(1, 16):
	print(i)