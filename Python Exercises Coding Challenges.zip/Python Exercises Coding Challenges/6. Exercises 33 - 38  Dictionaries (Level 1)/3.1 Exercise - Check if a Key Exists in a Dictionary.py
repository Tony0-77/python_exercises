my_dict = {"a": 1, "b": 2, "c": 3}
key = "d"

print(key in my_dict)