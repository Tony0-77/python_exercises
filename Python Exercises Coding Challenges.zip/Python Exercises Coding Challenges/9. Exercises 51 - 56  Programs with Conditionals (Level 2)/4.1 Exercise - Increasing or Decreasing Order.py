a = 3
b = 2
c = 1

if a > b > c:
	print("Decreasing Order")
elif a < b < c:
	print("Increasing Order")
else:
	print("None")